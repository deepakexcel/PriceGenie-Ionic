//vaibhav home controller
myappc.controller('homeCtrl', function ($scope, ajaxRequest, $http) {

//    var data={
//         action :'home_products_v1',
//    device : 'tablet',
//     key :'Books',
//    size : 10,
//     swipe : 1
//    };
//    
  var self=this;
  self.ajax=function(cat){
      cat = cat.replace(/[^a-zA-Z0-9]/gi, '');
        url2 = 'api.php?action=home_products_v1&size=10&device=tablet&swipe=1&key=' + cat;
        var promise = ajaxRequest.send(url2);
        promise.then(function (data) {
            var data = data.data;
            console.log(data);
            $scope.catItems1 = data;
        });
  };
  
          self.ajax('Mobiles & Tablets'); 
    $scope.loadLatest = function (cat) {
     self.ajax(cat);   
    };
});