//siddharth category controller
myappc.controller('viewallCtrl', function($scope, $ionicModal, ajaxRequest, $http) {
    var self = this;
    $ionicModal.fromTemplateUrl('my-modal.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function(modal) {
        $scope.modal = modal;
    });

    $scope.closeModal = function() {
        $scope.modal.hide();
        $scope.choice.A = null;
        $scope.choice.B = null;
        $scope.choice.C = null;
    };
    $scope.sort = function() {
        $scope.modal.show();
    };

    $scope.modalclose = function() {
        $scope.modal.hide();
        $scope.choice.A = null;
        $scope.choice.B = null;
        $scope.choice.C = null;
    };
    $scope.choice = {
        A: '',
        B: '',
        C: ''
    };


    self.AllData = function() {
        var action = 'all_products';
        var actual_link = 'catalog/xxx/1/-1/json__true';
        var api = 'api.php?action=' + action + '&actual_link=' + actual_link;
        var promise = ajaxRequest.send(api);
        promise.then(function(data) {
            $scope.response=data;
            console.log($scope.response);
    });
    };
    self.AllData();
});