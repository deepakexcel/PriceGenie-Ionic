//siddharth controller module
var myappc = angular.module('startercc', ['ionic','starter','starterss', 'ngStorage']);

myappc.controller('menuCtrl',function($scope,$state){
    $state.go('menu.home');
});

